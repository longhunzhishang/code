exports.__esModule = true;
exports['default'] = handlebars;
